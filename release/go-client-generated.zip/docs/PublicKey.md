# PublicKey

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HexBytes** | **string** | Hex-encoded public key bytes in the format specified by the CurveType. | [default to null]
**CurveType** | [***CurveType**](CurveType.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

