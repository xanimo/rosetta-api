# BlockEvent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sequence** | **int64** | sequence is the unique identifier of a BlockEvent within the context of a NetworkIdentifier. | [default to null]
**BlockIdentifier** | [***BlockIdentifier**](BlockIdentifier.md) |  | [default to null]
**Type_** | [***BlockEventType**](BlockEventType.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

