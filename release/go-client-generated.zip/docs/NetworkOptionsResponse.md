# NetworkOptionsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Version** | [***Version**](Version.md) |  | [default to null]
**Allow** | [***Allow**](Allow.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

