# BlockIdentifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Index** | **int64** | This is also known as the block height. | [default to null]
**Hash** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

