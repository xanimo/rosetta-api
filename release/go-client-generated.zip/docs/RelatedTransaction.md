# RelatedTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NetworkIdentifier** | [***NetworkIdentifier**](NetworkIdentifier.md) |  | [optional] [default to null]
**TransactionIdentifier** | [***TransactionIdentifier**](TransactionIdentifier.md) |  | [default to null]
**Direction** | [***Direction**](Direction.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

