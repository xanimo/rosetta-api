# ConstructionPreprocessRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NetworkIdentifier** | [***NetworkIdentifier**](NetworkIdentifier.md) |  | [default to null]
**Operations** | [**[]Operation**](Operation.md) |  | [default to null]
**Metadata** | [***interface{}**](interface{}.md) |  | [optional] [default to null]
**MaxFee** | [**[]Amount**](Amount.md) |  | [optional] [default to null]
**SuggestedFeeMultiplier** | **float64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

