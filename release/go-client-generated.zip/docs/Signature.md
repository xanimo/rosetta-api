# Signature

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SigningPayload** | [***SigningPayload**](SigningPayload.md) |  | [default to null]
**PublicKey** | [***PublicKey**](PublicKey.md) |  | [default to null]
**SignatureType** | [***SignatureType**](SignatureType.md) |  | [default to null]
**HexBytes** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

