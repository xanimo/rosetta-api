# IO.Swagger.Model.PublicKey
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HexBytes** | **string** | Hex-encoded public key bytes in the format specified by the CurveType. | 
**CurveType** | **CurveType** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

