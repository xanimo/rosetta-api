# IO.Swagger.Model.ConstructionPayloadsResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UnsignedTransaction** | **string** |  | 
**Payloads** | [**List&lt;SigningPayload&gt;**](SigningPayload.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

