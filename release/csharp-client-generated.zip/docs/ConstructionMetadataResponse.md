# IO.Swagger.Model.ConstructionMetadataResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metadata** | **Object** |  | 
**SuggestedFee** | [**List&lt;Amount&gt;**](Amount.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

