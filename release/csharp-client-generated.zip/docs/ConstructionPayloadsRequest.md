# IO.Swagger.Model.ConstructionPayloadsRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NetworkIdentifier** | [**NetworkIdentifier**](NetworkIdentifier.md) |  | 
**Operations** | [**List&lt;Operation&gt;**](Operation.md) |  | 
**Metadata** | **Object** |  | [optional] 
**PublicKeys** | [**List&lt;PublicKey&gt;**](PublicKey.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

