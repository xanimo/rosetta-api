# IO.Swagger.Model.RelatedTransaction
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NetworkIdentifier** | [**NetworkIdentifier**](NetworkIdentifier.md) |  | [optional] 
**TransactionIdentifier** | [**TransactionIdentifier**](TransactionIdentifier.md) |  | 
**Direction** | **Direction** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

