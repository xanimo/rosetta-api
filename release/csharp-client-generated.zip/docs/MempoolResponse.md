# IO.Swagger.Model.MempoolResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransactionIdentifiers** | [**List&lt;TransactionIdentifier&gt;**](TransactionIdentifier.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

