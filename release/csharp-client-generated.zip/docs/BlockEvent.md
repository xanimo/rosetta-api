# IO.Swagger.Model.BlockEvent
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sequence** | **long?** | sequence is the unique identifier of a BlockEvent within the context of a NetworkIdentifier. | 
**BlockIdentifier** | [**BlockIdentifier**](BlockIdentifier.md) |  | 
**Type** | **BlockEventType** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

