# IO.Swagger.Model.Signature
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SigningPayload** | [**SigningPayload**](SigningPayload.md) |  | 
**PublicKey** | [**PublicKey**](PublicKey.md) |  | 
**SignatureType** | **SignatureType** |  | 
**HexBytes** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

