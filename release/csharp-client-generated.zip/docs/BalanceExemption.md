# IO.Swagger.Model.BalanceExemption
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SubAccountAddress** | **string** | SubAccountAddress is the SubAccountIdentifier.Address that the BalanceExemption applies to (regardless of the value of SubAccountIdentifier.Metadata). | [optional] 
**Currency** | [**Currency**](Currency.md) |  | [optional] 
**ExemptionType** | **ExemptionType** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

