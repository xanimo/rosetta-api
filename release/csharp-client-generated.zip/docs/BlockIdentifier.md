# IO.Swagger.Model.BlockIdentifier
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Index** | **long?** | This is also known as the block height. | 
**Hash** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

