# IO.Swagger.Model.Block
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BlockIdentifier** | [**BlockIdentifier**](BlockIdentifier.md) |  | 
**ParentBlockIdentifier** | [**BlockIdentifier**](BlockIdentifier.md) |  | 
**Timestamp** | **long?** |  | 
**Transactions** | [**List&lt;Transaction&gt;**](Transaction.md) |  | 
**Metadata** | **Object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

