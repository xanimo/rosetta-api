# ConstructionPreprocessResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**options** | **object** | The options that will be sent directly to &#x60;/construction/metadata&#x60; by the caller. | [optional] 
**required_public_keys** | [**list[AccountIdentifier]**](AccountIdentifier.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

