# RelatedTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**network_identifier** | [**NetworkIdentifier**](NetworkIdentifier.md) |  | [optional] 
**transaction_identifier** | [**TransactionIdentifier**](TransactionIdentifier.md) |  | 
**direction** | [**Direction**](Direction.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

