# BlockTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**block_identifier** | [**BlockIdentifier**](BlockIdentifier.md) |  | 
**transaction** | [**Transaction**](Transaction.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

