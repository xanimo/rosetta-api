# ConstructionPayloadsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unsigned_transaction** | **str** |  | 
**payloads** | [**list[SigningPayload]**](SigningPayload.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

