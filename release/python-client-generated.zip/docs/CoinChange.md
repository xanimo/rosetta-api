# CoinChange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**coin_identifier** | [**CoinIdentifier**](CoinIdentifier.md) |  | 
**coin_action** | [**CoinAction**](CoinAction.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

