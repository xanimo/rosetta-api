# ConstructionPayloadsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**network_identifier** | [**NetworkIdentifier**](NetworkIdentifier.md) |  | 
**operations** | [**list[Operation]**](Operation.md) |  | 
**metadata** | **object** |  | [optional] 
**public_keys** | [**list[PublicKey]**](PublicKey.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

